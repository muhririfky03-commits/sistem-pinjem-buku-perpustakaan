-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table db_perpustakaan.books
CREATE TABLE IF NOT EXISTS `books` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `author` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `publisher` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `stock` int NOT NULL,
  `synopsis` text COLLATE utf8mb4_general_ci,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `cover_image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table db_perpustakaan.books: ~0 rows (approximately)
INSERT INTO `books` (`id`, `author`, `publisher`, `stock`, `synopsis`, `title`, `cover_image`) VALUES
	(1, 'test', 'test', 5, 'jwhfefce', 'test', 'fb3dc3db-2ce9-4fa4-b77f-c79011a3b8dc_1347921.jpg'),
	(2, 'test', 'test', 0, 'y\r\n', 't', 'cd2d2017-81b2-4a7c-8903-ea61c7fa1657_latar LSS.jpg'),
	(3, 'j', 'j', 0, 'j', 'k', '2adc54e9-a8ba-45ba-b759-b9d74abe713e_logo footer.png'),
	(4, 'i', 'o', 0, 'o', 'i', '2fbf9cfc-f5b0-4969-962f-de4acf9c912c_logo.png'),
	(5, 'l', 'i', 7, 'o', 'h', '76721e34-5cce-4a45-b951-edab136c2393_logo header.png'),
	(6, 'u', 'o', 0, 'i', 'v', NULL),
	(7, 'r', 'test', 8, 'u', 'w', NULL),
	(8, 'g', 'g', 0, 'g', 'g', NULL),
	(9, 'efj', 'ewf', 6, 'ejf', 'rv', NULL),
	(10, 'ef', 'ef', 0, 'eh', 'ef', NULL),
	(11, 'h', 'h', 8, 'jh', 'e', NULL);

-- Dumping structure for table db_perpustakaan.loans
CREATE TABLE IF NOT EXISTS `loans` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `due_date` date DEFAULT NULL,
  `loan_date` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `status` enum('DIAJUKAN','DIKEMBALIKAN','DIPINJAM','TERLAMBAT') COLLATE utf8mb4_general_ci DEFAULT NULL,
  `book_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKokwvlrv6o4i4h3le3bwhe6kie` (`book_id`),
  KEY `FK6xxlcjc0rqtn5nq28vjnx5t9d` (`user_id`),
  CONSTRAINT `FK6xxlcjc0rqtn5nq28vjnx5t9d` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FKokwvlrv6o4i4h3le3bwhe6kie` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table db_perpustakaan.loans: ~0 rows (approximately)
INSERT INTO `loans` (`id`, `due_date`, `loan_date`, `return_date`, `status`, `book_id`, `user_id`) VALUES
	(1, '2025-12-23', '2025-12-16', '2025-12-16', 'DIKEMBALIKAN', 1, 3),
	(2, '2025-12-23', '2025-12-16', NULL, 'DIAJUKAN', 1, 3),
	(3, '2025-12-23', '2025-12-16', NULL, 'DIAJUKAN', 5, 3),
	(4, '2025-12-23', '2025-12-16', NULL, 'DIAJUKAN', 8, 3),
	(5, '2025-12-23', '2025-12-16', NULL, 'DIAJUKAN', 5, 3),
	(6, '2025-12-23', '2025-12-16', NULL, 'DIAJUKAN', 9, 3);

-- Dumping structure for table db_perpustakaan.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `role` enum('ADMIN','VISITOR') COLLATE utf8mb4_general_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKr43af9ap4edm43mmtq01oddj6` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table db_perpustakaan.users: ~0 rows (approximately)
INSERT INTO `users` (`id`, `full_name`, `password`, `role`, `username`) VALUES
	(1, 'Administrator', '$2a$10$Yih/bWWqFmPuMPvGz2YOMOh/gSR0Kw5W2KNB1oMQLNMW5fojAFn3m', 'ADMIN', 'admin'),
	(2, 'Muhammad Solikhin', '$2a$10$OYffIUtvSct8i9bVHsVQTu//CWDH4M0OS0bQOjMnGZiZSh2ES/Ciy', 'VISITOR', 'solikhin'),
	(3, 'tes 123', '$2a$10$BCoHiCV7uX7NHZfYsQCbpulDnToTSD7Ty4xLSTTUAgb0Fic/7J8uu', 'VISITOR', 'tes');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
