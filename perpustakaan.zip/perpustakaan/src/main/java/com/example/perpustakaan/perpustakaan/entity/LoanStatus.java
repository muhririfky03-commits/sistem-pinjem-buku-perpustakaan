package com.example.perpustakaan.perpustakaan.entity;

public enum LoanStatus {
    DIAJUKAN,       
    DIPINJAM,       
    DIKEMBALIKAN,   
    TERLAMBAT
}