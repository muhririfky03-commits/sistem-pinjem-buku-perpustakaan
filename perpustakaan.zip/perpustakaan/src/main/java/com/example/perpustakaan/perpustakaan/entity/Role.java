package com.example.perpustakaan.perpustakaan.entity;

public enum Role {
    ADMIN,
    VISITOR
}